Hold Backspace and then plug in the cable. Continue to hold Backspace for 3 seconds to reset EEPROM.
Hold ESC and then plug the cable to jump bootloader.
