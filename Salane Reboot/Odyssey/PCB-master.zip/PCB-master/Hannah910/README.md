# Hannah910

![Hannah910](https://i.imgur.com/uF9CZN6.png)
Must see: https://imgur.com/gallery/gu0pFQc
Update:
 -Rev.2: add mx switch footprint top of right pcb.
 -Rev.3: add more layout. No pre-solder RGB LED top side, use ring of fire - LED module - waiting for prototype.
