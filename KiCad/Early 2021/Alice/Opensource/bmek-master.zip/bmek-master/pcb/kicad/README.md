# Kicad Project

There are two projects, one for the solder version, one for the hotswap version.

You'll need a recent nightly version of Kicad to open these (sorry, next time I'll use stable to create a project :) ).

This project contains V3 of the PCBs (see ../v3)
