# Elecrow Production Data
The zipped files in this directory contain all of the necessary files for PCB assembly at Elecrow.  
The included spec file is for 20 quantity in black. Please edit Unified-Daughterboard-Elecrow.xlsx and re-zip to change color and quantity options.