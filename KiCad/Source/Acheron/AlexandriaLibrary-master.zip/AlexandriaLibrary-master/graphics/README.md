# AcheronLibrary Grpahics folder

This folder contains the graphic files used to generate some of the footprints or general graphic features in the PCBs of the Acheron Project.

Please bear in mind that the Acheron Logo, Ares logo and Austin logo are proprietary and cannot be used in any way whatsoever without express communication from Gondolindrim.

All other logos (like the OSH logo) are property of their respective owners, so please consult the legal terms/licenses of these owner before using them.
