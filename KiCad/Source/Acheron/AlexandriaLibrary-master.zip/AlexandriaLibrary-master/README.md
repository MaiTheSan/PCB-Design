﻿# The Acheron Library 

<p align="center">
  <img align="middle" src="https://raw.githubusercontent.com/Gondolindrim/acheronLibrary/master/graphics/acheronLong.png"  width="400"> 
</p>

## Documentation

See [the AcheronDocs page](http://acheronproject.com/acheronLib/introduction.html) for the Acheron Library documentation.

## Licensing

The AcheronLibrary uses the BSD 3-clause License. Be sure to read it before using this library on a project.
